================================================================================
VB Dialog Sample
================================================================================

Will demonstrate how to create a dialog in Visual Basic and use the dialog from
R.

Remarks: 

* Arrays of Strings not supported by client
* Sample not finished
