================================================================================
Basic Test for internal COM server (C program)
================================================================================

First, start rgui, load library rcom, then start create1.exe

Output should be:

  successfully created COM object
  querying for IDispatch:          0
  querying for IStatConnector:          0

